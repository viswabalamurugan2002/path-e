import { Component } from '@angular/core';


@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent {
  email:any=""
  password:any=""
viswa:any=""

 sms(){

  
  if(this.email=="kevin"&& this.password=="kevin123"){
    this.viswa="password matched"
  }
  else{
    this.viswa="password not matched"

  }
  
}

}
